function Footer(){

  return(
    <div className="container-fuild bg-primary">
     
    <p className="text-center">Employee Management Software &copy; {new Date().getFullYear()} </p>
    </div>

  )
}
export default Footer