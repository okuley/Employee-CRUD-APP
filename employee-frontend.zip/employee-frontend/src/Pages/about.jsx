
function About(){

  return(
    <div className="container">
      <p className=""> 
        This this a simple Fullstack project with spring Boot and React.
      </p>
      <p>
      Connecting to Mysql database to save,get and delete records.
      </p>

    </div>
  )

}
export default About